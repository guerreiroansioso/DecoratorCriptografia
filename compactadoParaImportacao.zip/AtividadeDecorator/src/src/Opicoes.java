package src;

public class Opicoes
{
	private static int opicaoSelecionada = 0;
	
	public static void mostrarOpicoes()
	{
		System.out.println(":: Selecione uma opicao de critografia, porfavor"
				+ "\n (1) Sem criptografia."
				+ "\n (2) Com criptografia de Cezar."
				+ "\n (3) Com criptografia de V....."
				+ "\n (4) Cancelar e sair do programa.");
		
		if(opicaoSelecionada == 1)
		{
			
		} else if (opicaoSelecionada == 2)
		{
			
		} else if (opicaoSelecionada == 3)
		{
			
		} else if (opicaoSelecionada == 4)
		{
			
		}
	}
}
