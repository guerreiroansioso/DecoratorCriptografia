package src;

public interface Criptografia
{	
	public String criptografarMensagem(String mensagemRecebida);
	
	public String descriptografarMensagem(String mensagemRecebida);
}
